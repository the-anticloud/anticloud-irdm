# Result Register

**Project:** IRDM

| Result | Pass Condition | Command | Observed | Status |
| --- | --- | --- | --- | --- |
| (none yet) | (define before running) | (verbatim) | (unrecorded) | NOT RUN |
