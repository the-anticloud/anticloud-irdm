# 18 Command Line Interface

**Project:** IRDM
**Upstream:** https://github.com/caltechlibrary/irdm

Content specific to IRDM in category ACADEMIA_RD.
