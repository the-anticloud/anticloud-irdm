# Independent Insurance — IRDM

**Company:** Anticloud FZ LLE
**Model:** PAX L5 Narrow L2 General 27B
**Project:** IRDM | Category: ACADEMIA_RD
**Upstream:** https://github.com/caltechlibrary/irdm (MIT)

## Overview

This document covers independent insurance for the Anticloud integration of IRDM.

Institutional research data management

## Anticloud Integration

PAX L5 Narrow L2 General 27B is integrated into IRDM to provide:
- Local AI inference with zero cloud dependency
- AIOSS tamper-evident audit chain
- AES-256 encryption at rest
- Single-binary deployment

## Contact

Lois-Kleinner Alpasan — CEO & CTO, Anticloud FZ LLE
lois@0-1.gg | 0-1.gg
