# 19 System Of Things Sot

**Project:** IRDM
**Upstream:** https://github.com/caltechlibrary/irdm

Content specific to IRDM in category ACADEMIA_RD.
